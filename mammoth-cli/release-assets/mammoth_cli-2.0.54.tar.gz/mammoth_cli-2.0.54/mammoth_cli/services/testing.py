"""A typed fake :class:`~mammoth_cli.services.protocol.MammothService`.

Used by command tests in place of the real SDK-backed service so no network
call is ever made. Kept in the package (not ``tests/``) so both unit and
contract tests can import one shared fake, mirroring
:mod:`mammoth_cli.testing`.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from mammoth_cli.errors.envelope import (
    CODE_AUTHENTICATION_FAILED,
    CODE_RESOURCE_NOT_FOUND,
    EXIT_AUTH,
    EXIT_NOT_FOUND,
    CliError,
)


@dataclass
class FakeMammothService:
    """In-memory fake used by command tests instead of the real SDK service.

    Attributes:
        connection_ok: Whether :meth:`check_connection` succeeds.
        projects: The in-memory project records.
        calls: The ordered list of method names invoked, for assertions.
    """

    connection_ok: bool = True
    projects: list[dict[str, Any]] = field(default_factory=list)
    calls: list[str] = field(default_factory=list)
    responses: dict[str, Any] = field(default_factory=dict)
    call_log: list[tuple[str, dict[str, Any]]] = field(default_factory=list)
    view_responses: dict[tuple[int, str], Any] = field(default_factory=dict)
    view_call_log: list[tuple[int, str, dict[str, Any]]] = field(default_factory=list)
    wait_log: list[Any] = field(default_factory=list)
    wait_scopes: list[str] = field(default_factory=list)
    job_result: Any = None
    #: ``--dry-run`` hook, honoured like the production service does.
    gate: Callable[..., None] | None = None

    def call_view(self, view_id: int, method: str, /, **kwargs: Any) -> Any:
        """Record a View-method call and return a programmed response.

        Args:
            view_id: The dataview id the handler resolved.
            method: The View method or property name the handler dispatched to.
            **kwargs: The keyword arguments the handler passed; recorded in
                :attr:`view_call_log`.

        Returns:
            ``view_responses[(view_id, method)]`` if programmed (raised when it
            is an exception), else an empty mapping.
        """
        if self.gate is not None:
            self.gate(method, dict(kwargs), view_id=view_id, dataset_id=kwargs.get("dataset_id"))
        self.view_call_log.append((view_id, method, dict(kwargs)))
        key = (view_id, method)
        if key in self.view_responses:
            programmed = self.view_responses[key]
            if isinstance(programmed, Exception):
                raise programmed
            return programmed
        return {}

    def call(self, sdk_symbol: str, /, **kwargs: Any) -> Any:
        """Record the generic call and return a programmed response.

        Args:
            sdk_symbol: The symbol the handler dispatched to.
            **kwargs: The keyword arguments the handler passed; recorded in
                :attr:`call_log` so tests can assert exact field mapping.

        Returns:
            ``responses[sdk_symbol]`` if programmed (raised when it is an
            exception), else an empty mapping.
        """
        if self.gate is not None:
            self.gate(sdk_symbol, dict(kwargs))
        self.calls.append(sdk_symbol)
        self.call_log.append((sdk_symbol, dict(kwargs)))
        if sdk_symbol in self.responses:
            programmed = self.responses[sdk_symbol]
            if isinstance(programmed, Exception):
                raise programmed
            return programmed
        return {}

    def wait_if_job(self, response: Any, *, dashboard_url: str | None = None) -> Any:
        """Resolve a job-shaped response like the real service would.

        Records the call so handler tests can assert the CLI applied the job
        wait, and returns ``job_result`` when programmed (mirroring the real
        service resolving a job to its completed payload); otherwise returns the
        response unchanged, exactly as the real ``wait_if_job`` no-ops on a
        payload that is not a recognized job reference.
        """
        self.calls.append("wait_if_job")
        self.wait_log.append(response)
        if dashboard_url is not None:
            self.wait_scopes.append(dashboard_url)
        if self.job_result is not None:
            return self.job_result
        return response

    def check_connection(self) -> dict[str, Any]:
        """Simulate a lightweight connection check."""
        self.calls.append("check_connection")
        if not self.connection_ok:
            raise CliError(
                code=CODE_AUTHENTICATION_FAILED,
                message="Mammoth rejected the provided credentials.",
                exit_status=EXIT_AUTH,
                recovery_commands=["mammoth auth login"],
            )
        return {"projects": self.projects[:1]}

    def list_projects(self, limit: int = 100, offset: int = 0) -> dict[str, Any]:
        """Return the in-memory project list, sliced by offset/limit."""
        self.calls.append("list_projects")
        return {"projects": self.projects[offset : offset + limit]}

    def list_all_projects(self) -> list[dict[str, Any]]:
        """Return the whole in-memory project list."""
        self.calls.append("list_all_projects")
        return list(self.projects)

    def get_project(self, project_id: int) -> dict[str, Any]:
        """Return one in-memory project, or raise ``resource_not_found``."""
        self.calls.append("get_project")
        for project in self.projects:
            if project.get("id") == project_id:
                return project
        raise CliError(
            code=CODE_RESOURCE_NOT_FOUND,
            message=f"Project {project_id} does not exist.",
            exit_status=EXIT_NOT_FOUND,
        )

    def create_project(self, name: str, **kwargs: Any) -> dict[str, Any]:
        """Create an in-memory project record."""
        if self.gate is not None:
            self.gate("mammoth.api.projects.ProjectsAPI.create", {"name": name, **kwargs})
        self.calls.append("create_project")
        record = {"id": len(self.projects) + 1, "name": name}
        self.projects.append(record)
        return record

    def delete_project(self, project_id: int) -> dict[str, Any]:
        """Delete an in-memory project record."""
        if self.gate is not None:
            self.gate("mammoth.api.projects.ProjectsAPI.delete", {"project_id": project_id})
        self.calls.append("delete_project")
        self.projects = [p for p in self.projects if p.get("id") != project_id]
        return {"deleted": project_id}

    def close(self) -> None:
        """Record that the service was closed."""
        self.calls.append("close")

    def __enter__(self) -> FakeMammothService:
        """Enter the service as a context manager."""
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        """Close the service on context-manager exit."""
        self.close()
