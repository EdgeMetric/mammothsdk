"""Read-only handlers for the ``project`` command family.

Each handler receives the typed
:class:`~mammoth_cli.runtime.invocation.Invocation`, opens an authenticated
:class:`~mammoth_cli.services.protocol.MammothService`, and dispatches to the
public SDK method named by the command's reviewed manifest ``sdk_symbol``. No
handler constructs a client or reads process state directly; project ids come
from a positional argument or the resolved active project, and multi-field
input comes from the strict ``--input`` document.
"""

from __future__ import annotations

from typing import Any

from mammoth_cli.context import profiles
from mammoth_cli.errors.envelope import (
    CODE_INVALID_ARGUMENT,
    CODE_MISSING_ARGUMENT,
    CODE_MISSING_FIELD,
    CODE_SDK_SYMBOL_UNRESOLVED,
    EXIT_USAGE,
    CliError,
    missing_project_error,
)
from mammoth_cli.manifest.loader import command_by_id
from mammoth_cli.runtime.confirm import (
    POLICY_CONFIRM_TARGET,
    POLICY_PROMPT_OR_YES,
    POLICY_YES_ALWAYS,
    enforce_confirmation,
)
from mammoth_cli.runtime.invocation import Invocation
from mammoth_cli.runtime.session import open_service, resolved_project

HandlerResult = tuple[Any, dict[str, Any]]


def _symbol(invocation: Invocation) -> str:
    """Return the reviewed backing SDK symbol for this command."""
    record = command_by_id(invocation.command_id)
    if record is None or not record.get("sdk_symbol"):
        raise CliError(
            code=CODE_SDK_SYMBOL_UNRESOLVED,
            message=f"No SDK symbol is recorded for '{invocation.command_id}'.",
            exit_status=EXIT_USAGE,
        )
    return str(record["sdk_symbol"])


def _string_positional(invocation: Invocation) -> str | None:
    """Return the first positional argument, or None if absent."""
    return invocation.extra_args[0] if invocation.extra_args else None


def _int_positional(invocation: Invocation, name: str) -> int | None:
    """Parse the first positional argument as an int, or return None if absent."""
    if not invocation.extra_args:
        return None
    raw = invocation.extra_args[0]
    try:
        return int(raw)
    except ValueError as exc:
        raise CliError(
            code=CODE_INVALID_ARGUMENT,
            message=f"The {name} argument '{raw}' is not an integer.",
            exit_status=EXIT_USAGE,
        ) from exc


def _project_id(invocation: Invocation) -> int:
    """Resolve the target project id from a positional or the active project."""
    explicit = _int_positional(invocation, "project id")
    if explicit is not None:
        return explicit
    resolved = resolved_project(invocation)
    if resolved is None:
        raise missing_project_error()
    return resolved


def _require_input_field(document: dict[str, Any] | None, field: str) -> Any:
    """Return a required field from the ``--input`` document, or raise usage."""
    if document is None or field not in document:
        raise CliError(
            code=CODE_MISSING_FIELD,
            message=f"This command requires the '{field}' input field.",
            exit_status=EXIT_USAGE,
            hint=f"Pass it via --input, for example: --input '{{\"{field}\": ...}}'.",
        )
    return document[field]


def _meta(invocation: Invocation, auth_workspace_id: int, project_id: int | None) -> dict[str, Any]:
    """Build the common envelope metadata for a project command."""
    return {
        "profile": invocation.profile,
        "workspace_id": auth_workspace_id,
        "project_id": project_id,
    }


def _forward_optional(
    document: dict[str, Any], kwargs: dict[str, Any], fields: tuple[str, ...]
) -> None:
    """Copy any of ``fields`` present in ``document`` into ``kwargs``."""
    for field in fields:
        if field in document:
            kwargs[field] = document[field]


def project_list(invocation: Invocation) -> HandlerResult:
    """List projects in the active workspace, one page at a time.

    ``offset`` forwards for pagination past the server's 100-row page, the
    same as ``dataset list``; a short page's ``next`` in the response is
    empty. The server has no name filter for this route (unlike ``dataset
    list``'s discovery search), so none is exposed here.
    """
    document = invocation.load_input() or {}
    kwargs: dict[str, Any] = {"limit": int(document.get("limit", 100))}
    _forward_optional(document, kwargs, ("offset",))
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, resolved_project(invocation))


def project_get(invocation: Invocation) -> HandlerResult:
    """Get one project by id (positional or active project)."""
    project_id = _project_id(invocation)
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project=project_id)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_pending_changes(invocation: Invocation) -> HandlerResult:
    """Report a project's pending pipeline changes."""
    project_id = _project_id(invocation)
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_id=project_id)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_resource_status(invocation: Invocation) -> HandlerResult:
    """Report the status of a project's resources."""
    project_id = _project_id(invocation)
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_id=project_id)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_resource_dependencies(invocation: Invocation) -> HandlerResult:
    """Report dependencies for the given resource ids in a project."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    resource_ids = _require_input_field(document, "resource_ids")
    kwargs: dict[str, Any] = {"project_id": project_id, "resource_ids": resource_ids}
    if document is not None and "is_recursive" in document:
        kwargs["is_recursive"] = document["is_recursive"]
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_resource_dependencies_update(invocation: Invocation) -> HandlerResult:
    """Apply confirmed data-sync patches to a project's resource graph."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    patches = _require_input_field(document, "patches")
    if not isinstance(patches, list) or not patches:
        raise CliError(
            code=CODE_INVALID_ARGUMENT,
            message="'patches' must be a non-empty list.",
            exit_status=EXIT_USAGE,
        )
    targets: list[tuple[Any, Any]] = []
    for item in patches:
        if not isinstance(item, dict) or not isinstance(item.get("value"), dict):
            continue
        value = item["value"]
        targets.append((value.get("context_type"), value.get("context_id")))
    if len(targets) != len(set(targets)):
        raise CliError(
            code=CODE_INVALID_ARGUMENT,
            message="'patches' must not repeat a resource target.",
            exit_status=EXIT_USAGE,
        )
    with open_service(invocation) as (service, auth):
        enforce_confirmation(
            invocation,
            policy=POLICY_CONFIRM_TARGET,
            action=f"update resource data-sync settings in project {project_id}",
            target=str(project_id),
        )
        data = service.call(_symbol(invocation), project_id=project_id, patches=patches)
        settled = service.wait_if_job(data)
    if isinstance(data, dict) and isinstance(settled, dict):
        data = {**data, **settled}
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_publish_credentials(invocation: Invocation) -> HandlerResult:
    """Report publish credentials for a project's ODBC endpoint."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    odbc_type = _require_input_field(document, "odbc_type")
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_id=project_id, odbc_type=odbc_type)
    return data, _meta(invocation, auth.workspace_id, project_id)


_CREATE_OPTIONAL = ("color", "project_access")
_UPDATE_OPTIONAL = ("name", "color")


def project_create(invocation: Invocation) -> HandlerResult:
    """Create a project. Name comes from a positional or the ``name`` field."""
    document = invocation.load_input() or {}
    name = _string_positional(invocation) or document.get("name")
    if not name:
        raise CliError(
            code=CODE_MISSING_ARGUMENT,
            message="A project name is required.",
            exit_status=EXIT_USAGE,
            hint="Pass the name as a positional argument or a 'name' input field.",
        )
    kwargs: dict[str, Any] = {"name": name}
    for field in _CREATE_OPTIONAL:
        if field in document:
            kwargs[field] = document[field]
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, resolved_project(invocation))


_ENSURE_CREATE_SYMBOL = "mammoth.api.projects.ProjectsAPI.create"


def project_ensure(invocation: Invocation) -> HandlerResult:
    """Return the project with exactly this name, creating it when absent.

    Idempotent get-or-create for a scratch or working project (the "From
    Claude" convention: pick one project once, land every task's datasets
    there, sweep it with ``project delete``). Matching is exact and
    case-sensitive on the name; when several projects share the name the
    lowest id wins and ``duplicates`` lists the rest, so a re-run never
    creates a second one.
    """
    document = invocation.load_input() or {}
    name = _string_positional(invocation) or document.get("name")
    if not isinstance(name, str) or not name.strip():
        raise CliError(
            code=CODE_MISSING_ARGUMENT,
            message="A project name is required.",
            exit_status=EXIT_USAGE,
            hint="Pass the name as a positional argument or a 'name' input field.",
        )
    with open_service(invocation) as (service, auth):
        # Walks every 100-row page of the projects route, so an exact-name
        # match anywhere in the workspace is found before anything is created.
        projects = [p for p in service.list_all_projects() if isinstance(p, dict)]
        same_name = sorted(
            (p for p in projects if isinstance(p, dict) and p.get("name") == name),
            key=lambda p: int(p.get("id") or 0),
        )
        if same_name:
            chosen = same_name[0]
            data: dict[str, Any] = {
                "project": chosen,
                "project_id": chosen.get("id"),
                "created": False,
                "duplicates": [p.get("id") for p in same_name[1:]],
            }
            data["active"] = _make_active_project(invocation, data["project_id"])
            return data, _meta(invocation, auth.workspace_id, chosen.get("id"))
        created = service.call(_ENSURE_CREATE_SYMBOL, name=name)
    record = created.get("project", created) if isinstance(created, dict) else {}
    project_id = record.get("id") if isinstance(record, dict) else None
    if project_id is None and isinstance(created, dict):
        project_id = created.get("project_id") or created.get("id")
    data = {
        "project": record if isinstance(record, dict) else created,
        "project_id": project_id,
        "created": True,
        "duplicates": [],
    }
    data["active"] = _make_active_project(invocation, project_id)
    return data, _meta(invocation, auth.workspace_id, project_id)


def _make_active_project(invocation: Invocation, project_id: Any) -> bool:
    """Save ``project_id`` as the profile's active project; True when saved.

    ``project ensure`` exists so an agent picks its working project once;
    saving it here means no later command needs ``--project``. A profile-less
    run (environment login) has nowhere to save, and reports ``active: false``.
    """
    if not isinstance(project_id, int) or project_id <= 0:
        return False
    profile_name = invocation.profile or profiles.get_selected()
    existing = profiles.get_profile(profile_name)
    if existing is None:
        return False
    profiles.save_profile(
        profiles.ProfileRecord(
            name=existing.name,
            workspace_id=existing.workspace_id,
            server_prefix=existing.server_prefix,
            project_id=project_id,
        )
    )
    return True


def project_update(invocation: Invocation) -> HandlerResult:
    """Update a project's name or color from the ``--input`` document."""
    project_id = _project_id(invocation)
    document = invocation.load_input() or {}
    kwargs: dict[str, Any] = {"project_id": project_id}
    for field in _UPDATE_OPTIONAL:
        if field in document:
            kwargs[field] = document[field]
    if len(kwargs) == 1:
        raise CliError(
            code=CODE_MISSING_FIELD,
            message="Provide at least one of 'name' or 'color' to update.",
            exit_status=EXIT_USAGE,
            hint="Pass fields via --input.",
        )
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_delete(invocation: Invocation) -> HandlerResult:
    """Delete one project (positional or active).

    A project delete cascades to every dataset, view, export and dashboard in
    it, so it needs ``--yes --confirm PROJECT_ID``: the caller must name the
    exact project, not just agree to "the active one".
    """
    project_id = _project_id(invocation)
    enforce_confirmation(
        invocation,
        policy=POLICY_CONFIRM_TARGET,
        action=f"delete project {project_id}",
        target=str(project_id),
    )
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_id=project_id)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_bulk_delete(invocation: Invocation) -> HandlerResult:
    """Delete several projects by id. Prompt or ``--yes`` required."""
    document = invocation.load_input()
    project_ids = _require_input_field(document, "project_ids")
    enforce_confirmation(
        invocation,
        policy=POLICY_PROMPT_OR_YES,
        action=f"delete {len(project_ids)} projects",
    )
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_ids=project_ids)
    return data, _meta(invocation, auth.workspace_id, resolved_project(invocation))


def _bulk_update_project_ids(patch_data: Any) -> list[int]:
    """Return the project ids a ``ProjectsPatch`` body targets, or raise usage.

    The release contract is ``{"patches": [{"op", "path": "role", "value":
    [{"project_id", ...}]}]}``: every value item names the project it changes,
    so the CLI refuses a body that would not name its targets.
    """
    patches = patch_data.get("patches") if isinstance(patch_data, dict) else None
    targets: list[int] = []
    if isinstance(patches, list) and patches:
        for op in patches:
            values = op.get("value") if isinstance(op, dict) else None
            if not isinstance(values, list) or not values:
                targets = []
                break
            for item in values:
                project_id = item.get("project_id") if isinstance(item, dict) else None
                if not isinstance(project_id, int) or isinstance(project_id, bool):
                    targets = []
                    break
                targets.append(project_id)
            else:
                continue
            break
    if not targets:
        raise CliError(
            code=CODE_INVALID_ARGUMENT,
            message=(
                "patch_data must be a ProjectsPatch body whose every value item names a "
                "project_id."
            ),
            exit_status=EXIT_USAGE,
            hint=(
                'Shape: {"patch_data": {"patches": [{"op": "add", "path": "role", "value": '
                '[{"project_id": 41, "user_roles": [{"user_id": 3, "role": "project_admin"}]}]}]}}.'
            ),
        )
    return sorted(set(targets))


def project_bulk_update(invocation: Invocation) -> HandlerResult:
    """Apply a role patch across named projects. High-impact: ``--yes --confirm WS``."""
    document = invocation.load_input()
    patch_data = _require_input_field(document, "patch_data")
    project_ids = _bulk_update_project_ids(patch_data)
    with open_service(invocation) as (service, auth):
        enforce_confirmation(
            invocation,
            policy=POLICY_CONFIRM_TARGET,
            action=(
                f"bulk-update roles in projects {', '.join(str(p) for p in project_ids)} "
                f"of workspace {auth.workspace_id}"
            ),
            target=str(auth.workspace_id),
        )
        data = service.call(_symbol(invocation), patch_data=patch_data)
    return data, _meta(invocation, auth.workspace_id, resolved_project(invocation))


def project_sample_flow(invocation: Invocation) -> HandlerResult:
    """Create a sample flow in a project (positional or active)."""
    project_id = _project_id(invocation)
    document = invocation.load_input() or {}
    kwargs: dict[str, Any] = {"project_id": project_id}
    if "label_resource_id" in document:
        kwargs["label_resource_id"] = document["label_resource_id"]
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


_LIST_FILTER_OPTIONAL = ("fields", "sort", "dataview_id", "sequence", "status")


def _list_with_filters(invocation: Invocation) -> HandlerResult:
    """Shared handler for a project-scoped list with the standard filters."""
    project_id = _project_id(invocation)
    document = invocation.load_input() or {}
    kwargs: dict[str, Any] = {"project_id": project_id}
    for field in _LIST_FILTER_OPTIONAL:
        if field in document:
            kwargs[field] = document[field]
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_checkpoint_list(invocation: Invocation) -> HandlerResult:
    """List a project's checkpoints, with optional filters from ``--input``."""
    return _list_with_filters(invocation)


def project_data_check_list(invocation: Invocation) -> HandlerResult:
    """List a project's data checks, with optional filters from ``--input``."""
    return _list_with_filters(invocation)


def project_user_add(invocation: Invocation) -> HandlerResult:
    """Add users to a project. High-impact: ``--yes --confirm PROJECT_ID``."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    user_ids = _require_input_field(document, "user_ids")
    enforce_confirmation(
        invocation,
        policy=POLICY_CONFIRM_TARGET,
        action=f"add users to project {project_id}",
        target=str(project_id),
    )
    kwargs: dict[str, Any] = {"project_id": project_id, "user_ids": user_ids}
    assert document is not None
    if "role" in document:
        kwargs["role"] = document["role"]
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_user_remove(invocation: Invocation) -> HandlerResult:
    """Remove users from a project. High-impact: ``--yes --confirm PROJECT_ID``."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    user_ids = _require_input_field(document, "user_ids")
    enforce_confirmation(
        invocation,
        policy=POLICY_CONFIRM_TARGET,
        action=f"remove users from project {project_id}",
        target=str(project_id),
    )
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), project_id=project_id, user_ids=user_ids)
    return data, _meta(invocation, auth.workspace_id, project_id)


def project_user_update(invocation: Invocation) -> HandlerResult:
    """Update a project member's role (``role`` required; ``user_id``/``invite_id``)."""
    project_id = _project_id(invocation)
    document = invocation.load_input()
    role = _require_input_field(document, "role")
    kwargs: dict[str, Any] = {"project_id": project_id, "role": role}
    assert document is not None
    target_count = sum(
        field in document and document[field] is not None for field in ("user_id", "invite_id")
    )
    if target_count != 1:
        raise CliError(
            code=CODE_INVALID_ARGUMENT,
            message="Exactly one of 'user_id' or 'invite_id' is required.",
            exit_status=EXIT_USAGE,
        )
    for field in ("user_id", "invite_id"):
        if field in document:
            kwargs[field] = document[field]
    enforce_confirmation(
        invocation,
        policy=POLICY_YES_ALWAYS,
        action=f"update membership role in project {project_id}",
    )
    with open_service(invocation) as (service, auth):
        data = service.call(_symbol(invocation), **kwargs)
    return data, _meta(invocation, auth.workspace_id, project_id)


_DATASETS_LIST_SYMBOL = "mammoth.api.datasets.DatasetsAPI.list_all"
_DASHBOARDS_LIST_SYMBOL = "mammoth.api.dashboards.DashboardsAPI.list"


def _report_line(where: str, warning: dict[str, Any]) -> str:
    column = warning.get("column")
    subject = f"{where}, column {column}" if column else where
    return f"{subject}: {warning.get('issue')}. {warning.get('detail', '')}".strip()


def project_check(invocation: Invocation) -> HandlerResult:
    """List what a report on this project must still account for.

    Read-only local composite, run before reporting: for each dataset, the
    first view's ``column_warnings`` and ``before_dashboard``; for each
    dashboard, its ``deliverable_check``. ``to_report`` flattens them into
    one line per finding. Cold-agent evals (2.0.41) left one column's blanks
    undecided in every run, because the warning sat in an earlier result.
    """
    from mammoth_cli.commands.dashboard import _with_deliverable_check
    from mammoth_cli.commands.view import upload_preview

    project_id = _project_id(invocation)
    views: list[dict[str, Any]] = []
    dashboards: list[dict[str, Any]] = []
    to_report: list[str] = []
    with open_service(invocation) as (service, auth):
        listing = service.call(_DATASETS_LIST_SYMBOL, project_id=project_id)
        datasets = listing.get("datasets", []) if isinstance(listing, dict) else []
        for dataset in datasets:
            dataset_id = dataset.get("id") if isinstance(dataset, dict) else None
            if not isinstance(dataset_id, int):
                continue
            preview = upload_preview(service, dataset_id, project_id)
            if preview is None:
                continue
            entry = {
                "dataset_id": dataset_id,
                "dataset_name": dataset.get("name"),
                "view_id": preview["view_id"],
                "row_count": preview.get("row_count"),
                "column_warnings": preview.get("column_warnings", []),
            }
            if "before_dashboard" in preview:
                entry["before_dashboard"] = preview["before_dashboard"]
            other_views = preview.get("other_views")
            if other_views:
                # Only the first (most recent) view is previewed and checked.
                # Say so explicitly instead of letting silence read as "this
                # is the only view" -- which view to change is the user's
                # call unless they already named one.
                entry["other_views"] = other_views
                other_desc = ", ".join(f"{v['id']} ({v.get('name')})" for v in other_views)
                to_report.append(
                    f"dataset {dataset.get('name')} (id {dataset_id}) has "
                    f"{len(other_views) + 1} views; only view {preview['view_id']} was "
                    f"checked (others: {other_desc}). Which view to change is the "
                    "user's pick unless they named one."
                )
            views.append(entry)
            where = f"view {preview['view_id']} ({dataset.get('name')})"
            to_report += [_report_line(where, w) for w in entry["column_warnings"]]
        boards = service.call(_DASHBOARDS_LIST_SYMBOL, project_id=project_id)
        for board in boards if isinstance(boards, list) else []:
            dashboard_id = board.get("id") if isinstance(board, dict) else None
            if not isinstance(dashboard_id, int):
                continue
            checked = _with_deliverable_check(
                invocation, service, auth, {"dashboard_id": dashboard_id}, {"id": dashboard_id}
            )
            check = checked.get("deliverable_check") if isinstance(checked, dict) else None
            warnings = check.get("warnings", []) if isinstance(check, dict) else []
            dashboards.append(
                {"id": dashboard_id, "title": board.get("title"), "warnings": warnings}
            )
            to_report += [_report_line(f"dashboard {dashboard_id}", w) for w in warnings]
        meta = _meta(invocation, auth.workspace_id, project_id)
    return {
        "project_id": project_id,
        "views": views,
        "dashboards": dashboards,
        "to_report": to_report,
        "note": (
            "Before you report: fix each finding, or give it one line in the report "
            "(what you did and why). A finding you do not mention is a miss."
            if to_report
            else "Nothing open in the views or dashboards."
        ),
    }, meta
